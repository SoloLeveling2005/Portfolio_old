<template>
    <div class="home">
        <section class="ab-info-main py-md-5 py-4 editContent">
            <div class="container-fluid py-md-3">
                <div class="row">
                    <div class="side-bar col-lg-3">
                        <div class="search-bar w3layouts-newsletter">
                            <h3 class="sear-head editContent">Поиск фильма</h3>
                            <form action="#" method="post" class="d-flex editContent">
                                <input type="search" placeholder="Введите название..." name="search"
                                       class="form-control" required="">
                                <button class="btn1 btn"><span class="fa fa-search"
                                                               aria-hidden="true"></span></button>
                            </form>
                        </div>

                        <div class="left-side my-4">
                            <h3 class="sear-head editContent">Жанры</h3>
                            <ul class="w3layouts-box-list">
                                <li class="editContent">
                                    <input type="checkbox" class="checked">
                                    <span class="span editContent">Аниме</span>
                                </li>
                                <li class="editContent">
                                    <input type="checkbox" class="checked">
                                    <span class="span editContent">Боевики</span>
                                </li>
                                <li class="editContent">
                                    <input type="checkbox" class="checked">
                                    <span class="span editContent">Комедии</span>
                                </li>
                                <li class="editContent">
                                    <input type="checkbox" class="checked">
                                    <span class="span editContent">Ужасы</span>
                                </li>
                            </ul>
                        </div>

                        <div class="left-side">
                            <h3 class="sear-head editContent">Год</h3>
                            <ul class="w3layouts-box-list">
                                <li class="editContent">
                                    <input type="checkbox" class="checked">
                                    <span class="span editContent">2020</span>
                                </li>
                            </ul>
                        </div>

                        <div class="customer-rev left-side my-4">
                            <h3 class="sear-head editContent">Рейтинг</h3>
                            <ul class="w3layouts-box-list">
                                <li>
                                    <a href="#">
                                        <span class="fa fa-star" aria-hidden="true"></span>
                                        <span class="fa fa-star" aria-hidden="true"></span>
                                        <span class="fa fa-star" aria-hidden="true"></span>
                                        <span class="fa fa-star" aria-hidden="true"></span>
                                        <span class="fa fa-star" aria-hidden="true"></span>
                                        <span class="editContent">5.0</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <span class="fa fa-star" aria-hidden="true"></span>
                                        <span class="fa fa-star" aria-hidden="true"></span>
                                        <span class="fa fa-star" aria-hidden="true"></span>
                                        <span class="fa fa-star" aria-hidden="true"></span>
                                        <span class="fa fa-star-o" aria-hidden="true"></span>
                                        <span class="editContent">4.0</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <span class="fa fa-star" aria-hidden="true"></span>
                                        <span class="fa fa-star" aria-hidden="true"></span>
                                        <span class="fa fa-star" aria-hidden="true"></span>
                                        <span class="fa fa-star-half-o" aria-hidden="true"></span>
                                        <span class="fa fa-star-o" aria-hidden="true"></span>
                                        <span class="editContent">3.5</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <span class="fa fa-star" aria-hidden="true"></span>
                                        <span class="fa fa-star" aria-hidden="true"></span>
                                        <span class="fa fa-star" aria-hidden="true"></span>
                                        <span class="fa fa-star-o" aria-hidden="true"></span>
                                        <span class="fa fa-star-o" aria-hidden="true"></span>
                                        <span class="editContent">3.0</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <span class="fa fa-star" aria-hidden="true"></span>
                                        <span class="fa fa-star" aria-hidden="true"></span>
                                        <span class="fa fa-star-half-o" aria-hidden="true"></span>
                                        <span class="fa fa-star-o" aria-hidden="true"></span>
                                        <span class="fa fa-star-o" aria-hidden="true"></span>
                                        <span class="editContent">2.5</span>
                                    </a>
                                </li>
                            </ul>
                        </div>

                        <div class="deal-leftmk left-side">
                            <h3 class="sear-head editContent">Последние добавленные</h3>
                            <div class="special-sec1 row mt-3 editContent">
                                <div class="img-deals col-md-4">
                                    <img src="bundles/images/s4.jpg" class="img-fluid" alt="">
                                </div>
                                <div class="img-deal1 col-md-4">
                                    <h3 class="editContent">Рэмбо: Последняя кровь</h3>
                                    <a href="moviesingle.html" class="editContent"></a>
                                </div>

                            </div>
                            <div class="special-sec1 row mt-3 editContent">
                                <div class="img-deals col-md-4">
                                    <img src="bundles/images/s2.jpg" class="img-fluid" alt="">
                                </div>
                                <div class="img-deal1 col-md-8">
                                    <h3 class="editContent">Холодное сердце 2</h3>
                                    <a href="moviesingle.html" class="editContent"></a>
                                </div>

                            </div>
                            <div class="special-sec1 row mt-3 editContent">
                                <div class="img-deals col-md-4">
                                    <img src="bundles/images/s1.jpg" class="img-fluid" alt="">
                                </div>
                                <div class="img-deal1 col-md-8">
                                    <h3 class="editContent">К звездам</h3>
                                    <a href="moviesingle.html" class="editContent"></a>
                                </div>

                            </div>
                            <div class="special-sec1 row mt-3 editContent">
                                <div class="img-deals col-md-4">
                                    <img src="bundles/images/s5.jpg" class="img-fluid" alt="">
                                </div>
                                <div class="img-deal1 col-md-8">
                                    <h3 class="editContent">Терминатор: Темные судьбы</h3>
                                    <a href="moviesingle.html" class="editContent"></a>
                                </div>

                            </div>
                            <div class="special-sec1 row mt-3 editContent">
                                <div class="img-deals col-md-4">
                                    <img src="bundles/images/s3.jpg" class="img-fluid" alt="">
                                </div>
                                <div class="img-deal1 col-md-8">
                                    <h3 class="editContent">Джокер</h3>
                                    <a href="moviesingle.html" class="editContent"></a>
                                </div>

                            </div>
                        </div>
                        <!-- //deals -->
                    </div>

                    <div class="left-ads-display col-lg-9">
                        <div class="row">
                            <div v-for="movie in listMovie" :key="movie.id" class="col-md-4 product-men">
                                <div class="product-shoe-info editContent text-center mt-lg-4">
                                    <div class="men-thumb-item">
                                        <img :src="movie.poster" class="img-fluid" alt="">
                                    </div>
                                    <div class="item-info-product">
                                        <h4 class="">
                                            <a href="#" @click="goTo(movie.id)" class="editContent">{{ movie.title }}</a>
                                        </h4>

                                        <div class="product_price">
                                            <div class="grid-price">
                                                <span class="money editContent">{{movie.tagline}}</span>
                                            </div>
                                        </div>
                                        <ul class="stars">
                                            <li v-for="star in listStar" :key="star">
                                                <a href="#">
                                                    <span class="fa"
                                                          :class="star <= movie.middle_star ? 'fa-star' : 'fa-star-o' "
                                                          aria-hidden="true">
                                                    </span>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</template>

<script>
    export default {
        name: 'Home',
        data() {
            return {
                listMovie: [],
                listStar: [1, 2, 3, 4, 5]
            }
        },
        components: {},
        created() {
            this.loadListMovies()
        },
        methods: {
            async loadListMovies() {
                this.listMovie = await fetch(
                    `${this.$store.getters.getServerUrl}/movie`
                ).then(response => response.json())
            },
            goTo(id) {
                this.$router.push({ name: 'Single', params: {id: id} })
            }
        }
    }
</script>

<style scoped>
    .editContent {
        padding-left: 3rem;
        padding-right: 3rem;
    }
</style>
